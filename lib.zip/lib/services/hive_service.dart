import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/recipe.dart';
import '../models/user_profile.dart';

class HiveService {
  static late Box<Recipe> recipesBox;
  static late Box<UserProfile> usersBox;

  static Future<void> init() async {
    recipesBox = await Hive.openBox<Recipe>('recipes');
    usersBox = await Hive.openBox<UserProfile>('users');

    print('=== HIVE INIT ===');
    print('Recipes box: ${recipesBox.values.length} recipes');
    print('Users box: ${usersBox.values.length} users');

    // DEBUG: Afficher toutes les clés
    print('Recipe box keys: ${recipesBox.keys.toList()}');
  }

  // === RECIPES ===
  static Future<int> addRecipe(Recipe recipe) async {
    print('HIVE: addRecipe "${recipe.title}" with isCustom: ${recipe.isCustom}');
    print('HIVE: Recipe key before add: ${recipe.key}');
    final key = await recipesBox.add(recipe);
    print('HIVE: Added with key: $key');

    // Vérifier après ajout
    final addedRecipe = recipesBox.get(key);
    print('HIVE: After add - key: $key, title: "${addedRecipe?.title}", owner: "${addedRecipe?.ownerName}"');
    return key;
  }

  static List<Recipe> getAllRecipes() {
    final recipes = recipesBox.values.toList();
    print('HIVE: getAllRecipes returned ${recipes.length} recipes');

    // DEBUG détaillé
    for (var i = 0; i < recipes.length; i++) {
      final r = recipes[i];
      print('HIVE: [$i] key: ${r.key}, title: "${r.title}", owner: "${r.ownerName}", isCustom: ${r.isCustom}');
    }

    return recipes;
  }

  static Future<void> updateRecipe(int key, Recipe recipe) async {
    print('=== HIVE updateRecipe START ===');
    print('HIVE: Updating key: $key');

    // VÉRIFIER SI LA CLÉ EXISTE
    if (!recipesBox.containsKey(key)) {
      print('HIVE ERROR: Key $key does not exist in box!');
      print('HIVE: Available keys: ${recipesBox.keys.toList()}');
      print('=== HIVE updateRecipe END (ERROR) ===');
      return;
    }

    final before = recipesBox.get(key);
    if (before == null) {
      print('HIVE ERROR: No recipe found with key $key!');
      print('=== HIVE updateRecipe END (ERROR) ===');
      return;
    }

    print('HIVE: Before update:');
    print('  - key: $key');
    print('  - title: "${before.title}"');
    print('  - owner: "${before.ownerName}"');
    print('  - isCustom: ${before.isCustom}');
    print('  - has key property: ${before.key}');

    print('HIVE: New recipe data:');
    print('  - title: "${recipe.title}"');
    print('  - owner: "${recipe.ownerName}"');
    print('  - isCustom: ${recipe.isCustom}');
    print('  - has key property: ${recipe.key}');

    // SAUVEGARDER
    await recipesBox.put(key, recipe);

    // VÉRIFIER APRÈS
    final after = recipesBox.get(key);
    print('HIVE: After update:');
    print('  - key: $key');
    print('  - title: "${after?.title}"');
    print('  - owner: "${after?.ownerName}"');
    print('  - isCustom: ${after?.isCustom}');
    print('  - has key property: ${after?.key}');

    print('HIVE: Title changed: "${before.title}" -> "${after?.title}" = ${before.title != after?.title}');
    print('=== HIVE updateRecipe END ===');
  }

  static Future<void> deleteRecipe(int key) async {
    print('HIVE: deleteRecipe key $key');

    final recipe = recipesBox.get(key);
    if (recipe != null) {
      print('HIVE: Deleting "${recipe.title}" (key: $key)');
    }

    await recipesBox.delete(key);

    // Vérifier après suppression
    print('HIVE: After delete, box has ${recipesBox.length} recipes');
  }

  // === UTILS ===
  static void debugAllRecipes() {
    print('=== HIVE DEBUG ALL RECIPES ===');
    print('Total recipes: ${recipesBox.length}');
    print('Keys: ${recipesBox.keys.toList()}');

    for (var key in recipesBox.keys) {
      final recipe = recipesBox.get(key);
      print('Key $key: "${recipe?.title}" | owner: "${recipe?.ownerName}" | isCustom: ${recipe?.isCustom} | recipe.key: ${recipe?.key}');
    }
    print('=== END DEBUG ===');
  }

  // === USERS ===
  static Future<void> addUser(UserProfile user) async {
    print('Hive: addUser "${user.name}"');
    await usersBox.put(user.name.toLowerCase(), user);
  }

  static UserProfile? getUser(String username) {
    return usersBox.get(username.toLowerCase());
  }
}