import 'package:flutter/foundation.dart';
import '../models/recipe.dart';
import '../services/api_service.dart';
import '../services/hive_service.dart';

class RecipeProvider extends ChangeNotifier {
  final ApiService _apiService = ApiService();

  bool _isLoading = false;
  List<Recipe> _apiRecipes = [];
  List<Recipe> _favorites = [];
  String? _currentUserName;

  bool get isLoading => _isLoading;
  List<Recipe> get apiRecipes => _apiRecipes;
  List<Recipe> get favorites => _favorites;

  Future<void> setCurrentUser(String? userName) async {
    print('=== setCurrentUser: $userName ===');
    _currentUserName = userName;
    await loadFavorites();
  }

  Future<void> fetchRecipesForMood(String moodKeyword) async {
    _isLoading = true;
    notifyListeners();
    try {
      _apiRecipes = await _apiService.fetchRecipesByKeyword(moodKeyword);
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadFavorites() async {
    print('=== loadFavorites ===');
    print('Current user: $_currentUserName');

    if (_currentUserName == null) {
      print('No user, empty list');
      _favorites = [];
      notifyListeners();
      return;
    }

    final allRecipes = HiveService.getAllRecipes();
    print('Total in Hive: ${allRecipes.length}');

    for (var r in allRecipes) {
      print(' - "${r.title}" | owner: "${r.ownerName}" | key: ${r.key} | isCustom: ${r.isCustom}');
    }

    _favorites = allRecipes.where((r) => r.ownerName == _currentUserName).toList();
    print('Filtered favorites: ${_favorites.length}');

    notifyListeners();
  }

  Future<void> addFavorite(Recipe recipe) async {
    print('=== addFavorite ===');
    print('User: $_currentUserName');
    print('Recipe: ${recipe.title} | isCustom: ${recipe.isCustom}');

    if (_currentUserName == null) {
      print('ERROR: No user!');
      return;
    }

    final recipeWithOwner = recipe.copyWith(ownerName: _currentUserName);
    final key = await HiveService.addRecipe(recipeWithOwner);
    print('Added with key: $key');

    await loadFavorites();
  }

  Future<void> updateFavorite(Recipe recipe) async {
    print('=== updateFavorite START ===');
    print('Recipe to update:');
    print('- Title: "${recipe.title}"');
    print('- Owner: "${recipe.ownerName}"');
    print('- Has key: ${recipe.key != null}');
    print('- Key: ${recipe.key}');
    print('- isCustom: ${recipe.isCustom}');

    if (_currentUserName == null) {
      print('ERROR: No current user!');
      return;
    }

    // APPROCHE SIMPLE : Si la recette a une clé, mettre à jour directement
    if (recipe.key != null) {
      print('Recipe has key: ${recipe.key}, updating directly...');
      await HiveService.updateRecipe(recipe.key!, recipe);
    } else {
      print('ERROR: Recipe has NO key! This should not happen if using copyWith()');

      // FALLBACK : Chercher la recette par ANCIEN titre dans les favoris actuels
      // On suppose que l'utilisateur modifie sa recette la plus récente
      if (_favorites.isNotEmpty) {
        final latestCustomRecipe = _favorites
            .where((r) => r.isCustom == true)
            .last; // La plus récente

        if (latestCustomRecipe.key != null) {
          print('Updating latest custom recipe: "${latestCustomRecipe.title}" key: ${latestCustomRecipe.key}');

          // Créer une recette mise à jour avec l'ANCIENNE clé
          final updatedWithKey = latestCustomRecipe.copyWith(
            title: recipe.title,
            category: recipe.category,
            instructions: recipe.instructions,
            imageUrl: recipe.imageUrl,
          );

          await HiveService.updateRecipe(latestCustomRecipe.key!, updatedWithKey);
        } else {
          print('ERROR: Latest recipe has no key either!');
          await addFavorite(recipe);
        }
      } else {
        print('No favorites found, adding as new');
        await addFavorite(recipe);
      }
    }

    await loadFavorites();
    print('=== updateFavorite END ===');
  }

  Future<void> deleteFavorite(Recipe recipe) async {
    print('=== deleteFavorite ===');

    if (recipe.key != null) {
      await HiveService.deleteRecipe(recipe.key!);
    } else {
      print('WARNING: Recipe has no key, trying to find by title...');
      final allRecipes = HiveService.getAllRecipes();
      for (var r in allRecipes) {
        if (r.title == recipe.title && r.ownerName == _currentUserName) {
          if (r.key != null) {
            await HiveService.deleteRecipe(r.key!);
          }
          break;
        }
      }
    }

    await loadFavorites();
  }

  bool isRecipeInFavorites(Recipe recipe) {
    return _favorites.any((fav) =>
    fav.title == recipe.title &&
        fav.ownerName == recipe.ownerName
    );
  }
}